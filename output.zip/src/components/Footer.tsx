export function Footer() {
  return (
    <footer className='footer'>
      <div>
        <p>
          Copyright &copy; {new Date().getFullYear()} Adam Grimmehed. All rights
          reserved.
        </p>
      </div>
    </footer>
  )
}
